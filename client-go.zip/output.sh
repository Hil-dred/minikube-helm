#!/bin/sh

./client-go-binary > ./podnames.txt